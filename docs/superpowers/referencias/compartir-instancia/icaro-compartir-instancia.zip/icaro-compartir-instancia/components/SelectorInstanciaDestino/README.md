# SelectorInstanciaDestino

Dónde poner lo que llega: una instancia nueva (lo recomendado) o una existente compatible. Adapta el selector de instancias para explicar cada incompatibilidad en vez de esconderla.

## Compatibilidad

| Estado | Insignia | Explicación | ¿Se puede elegir? |
| --- | --- | --- | --- |
| Compatible | exito | Qué va a pasar con sus mods | Sí |
| Minecraft distinto | error | "Necesita Minecraft 1.21.1 y esta usa 1.21.4. Crea una nueva o cambia su versión." | No |
| Loader distinto | error | "Necesita NeoForge y esta usa Fabric. Los mods de un loader no funcionan en el otro." | No |
| Instancia ocupada | alerta | "Minecraft está abierto con esta instancia. Ciérralo para poder sincronizarla." | No, hasta que se cierre; la fila se habilita sola |

## Reglas

- Crear instancia nueva va primero y viene elegida; su nombre se puede editar.
- Elegir una existente muestra el aviso: "Se cambiarán sus mods para que coincidan con los de Mineral_7. Tus mundos no se tocan. Antes se guarda una copia de seguridad."
- Las incompatibles quedan en la lista, atenuadas, con su motivo visible (no en un tooltip).

## En iced

Lista de `radio` con `on_select` condicionado; la compatibilidad se calcula comparando `version_id` y `loader` del manifiesto de la revisión con los de cada instancia, y si hay un proceso de Minecraft con esa carpeta.
