# AccesosCompartidos

Las sesiones que aceptaron una invitación del anfitrión: quién es, su huella, si está conectado y qué está haciendo, y la opción de revocar. Al final, Dejar de compartir, que revoca todo.

## Filas

- Cabeza de la skin (o icono procedural), nombre, los primeros 8 caracteres de su huella en `mono-sm` y el estado con punto: "Conectado · descargando 64 %", "Conectado · al día con la revisión 7", "Sin conexión desde ayer, 22:40".
- Fecha en que aceptó.
- **Revocar** confirma en la misma fila: "Su instancia queda como está, pero deja de recibir cambios y se corta lo que esté descargando".

## Dejar de compartir

Bloque al final con borde, texto de consecuencia y botón de peligro. Revoca todas las sesiones e invitaciones vigentes. Si hay transferencias activas abre CierreConTransferencias.

## Vacío

"Nadie tiene acceso. Quien acepte una invitación aparecerá aquí."

## En iced

Cada sesión es un par de claves del invitado (Ed25519) autorizado por el anfitrión; revocar borra la clave de la lista de permitidas y cierra su conexión.
