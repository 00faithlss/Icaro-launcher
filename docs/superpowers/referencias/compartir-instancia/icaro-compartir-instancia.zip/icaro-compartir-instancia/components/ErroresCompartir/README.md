# ErroresCompartir

Los errores de compartir y sincronizar, escritos para que se entienda qué pasó, qué quedó como estaba y qué hacer. Aparecen en el lugar del progreso (ProgresoSincronizacion) o del panel (PanelPublicacion), nunca como diálogo suelto.

## Catálogo

| Error | Qué pasó | Qué queda | Acción |
| --- | --- | --- | --- |
| Espacio insuficiente | Faltan X GB en la unidad | Nada cambió | Liberar espacio · Elegir otra unidad |
| Archivo cambiado | Un archivo cambió en el anfitrión durante la descarga | Lo demás se aprovecha | Volver a revisar |
| Hash incorrecto | Un archivo llegó dañado; se reintenta una vez sola | Nada cambió | Reintentar · Ver detalle |
| Límite excedido | El anfitrión está en su máximo de envíos simultáneos o de tamaño | En cola | Esperar |
| Revisión desactualizada | El anfitrión publicó otra revisión | Lo descargado se aprovecha | Revisar la nueva |
| Acceso revocado | El anfitrión revocó la sesión | La instancia queda como está | Entendido · Desvincular |

Todos usan `ic-aviso--error` salvo Límite excedido y Revisión desactualizada, que son `alerta` porque se resuelven solos o con un clic.

## Reglas

- Siempre decir qué quedó como estaba: "Amigos queda como está", "Nada cambió".
- El nombre del archivo va en `mono-sm`; el detalle técnico (hash esperado y recibido) en Ver detalle, no en el texto principal.
