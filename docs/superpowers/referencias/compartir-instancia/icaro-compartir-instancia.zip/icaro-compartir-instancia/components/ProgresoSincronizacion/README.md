# ProgresoSincronizacion

El avance de la sincronización en cuatro fases y su resultado. Reutiliza Progreso y la cuadrícula de bloques de Integridad, con un riel de fases arriba.

## Fases

1. **Preparación**: copia de seguridad de la instancia y lista de archivos.
2. **Descarga**: de Modrinth y CurseForge en paralelo; los archivos propios, del anfitrión. Bytes, velocidad y archivo en curso en `mono-sm`.
3. **Verificación**: hash de cada archivo descargado contra el manifiesto.
4. **Aplicación**: mover a la instancia de forma atómica; nada cambia hasta esta fase.

Cada fase terminada queda marcada con verificación; la actual, con spinner.

## Estados finales

| Estado | Texto | Acción |
| --- | --- | --- |
| Cancelado | "No se cambió nada en Amigos. Lo descargado queda guardado para la próxima vez." | Cerrar · Reintentar |
| Recuperando | "Ícaro se cerró mientras aplicaba. Restaurando la copia de seguridad de Amigos…" | Esperar (sin botones) |
| Completado | "Amigos está en la revisión 7: 3 altas, 2 actualizaciones, 1 retirada." | Jugar · Ver cambios |

Cancelar está disponible hasta la aplicación; durante la aplicación se deshabilita ("Aplicando: no se puede cancelar en este paso").

## En iced

Una `Task::sip` que emite `Progreso { fase, hechos, total, bytes }`; la aplicación escribe en una carpeta temporal y hace `rename` por archivo, registrando cada paso en un diario para poder recuperarse.
