/* @ds-bundle: {"format": 4, "namespace": "Icaro", "components": [{"name": "Umbral"}, {"name": "BotonJugar"}, {"name": "Lamina"}, {"name": "Lupa"}, {"name": "Detalle"}, {"name": "Banda"}, {"name": "Gabinete"}, {"name": "LaminaASCII"}, {"name": "Boton"}, {"name": "Campo"}, {"name": "Selector"}, {"name": "Contador"}, {"name": "Interruptores"}, {"name": "Chips"}, {"name": "Apariencia"}, {"name": "ZonaSoltar"}, {"name": "SelectorColor"}, {"name": "Tarjeta"}, {"name": "Insignia"}, {"name": "Progreso"}, {"name": "Tooltip"}, {"name": "Senal"}, {"name": "Almacenamiento"}, {"name": "Avatar"}, {"name": "BloqueCodigo"}, {"name": "Tabla"}, {"name": "Consola"}, {"name": "Explorador"}, {"name": "ListaVirtual"}, {"name": "ListaReordenable"}, {"name": "AppShell"}, {"name": "Pestanas"}, {"name": "MenuBandeja"}, {"name": "Dialogo"}, {"name": "MenuContextual"}, {"name": "Toast"}, {"name": "InformeFallo"}, {"name": "PanelLateral"}, {"name": "PantallaError"}, {"name": "TarjetaInstancia"}, {"name": "Asistente"}, {"name": "CodigoDispositivo"}, {"name": "SelectorCuenta"}, {"name": "FilaMod"}, {"name": "TarjetaServidor"}, {"name": "ColaDescargas"}, {"name": "Capturas"}, {"name": "FilaAjuste"}, {"name": "EstadoVacio"}, {"name": "PrimeraEjecucion"}, {"name": "EditorInstancia"}, {"name": "AccionesInstancia"}, {"name": "SelectorVersion"}, {"name": "SelectorLoader"}, {"name": "SincronizarMods"}, {"name": "Integridad"}, {"name": "AjustesJava"}, {"name": "DeslizadorMemoria"}, {"name": "AjustesAlmacenamiento"}, {"name": "AjustesGenerales"}, {"name": "CambioVersionInstancia"}, {"name": "Picar"}, {"name": "ExportarInstancia"}, {"name": "IconoInstancia"}, {"name": "ModoRendimiento"}, {"name": "ModsInstancia"}, {"name": "ArchivosInstancia"}, {"name": "TiendaMods"}, {"name": "FichaMod"}, {"name": "InfoProyecto"}, {"name": "PaginaMod"}, {"name": "ExportarModpack"}, {"name": "ArchivosNoVerificados"}, {"name": "RecursosInstancia"}, {"name": "MundosInstancia"}, {"name": "ExportarListaMods"}, {"name": "CompartirInstancia"}, {"name": "ConfirmarJarPropios"}, {"name": "InvitacionCompartir"}, {"name": "AccesosCompartidos"}, {"name": "PanelPublicacion"}, {"name": "EntradaInvitacion"}, {"name": "IdentidadAnfitrion"}, {"name": "SelectorInstanciaDestino"}, {"name": "RevisionSincronizacion"}, {"name": "ProgresoSincronizacion"}, {"name": "ErroresCompartir"}, {"name": "ResumenConexion"}, {"name": "CierreConTransferencias"}, {"name": "EstadosSesion"}, {"name": "ImportarClonar"}, {"name": "CambiarVersion"}, {"name": "BibliotecaMods"}, {"name": "VisorCaptura"}, {"name": "PantallaServidores"}, {"name": "RedPrivada"}, {"name": "PantallaDescargas"}, {"name": "PantallaConsola"}, {"name": "PantallaAjustes"}, {"name": "ActualizacionLauncher"}, {"name": "ImportarModpack"}, {"name": "CuentaSinConexion"}, {"name": "SkinSinConexion"}, {"name": "PantallaCuenta"}, {"name": "EstudioSkin"}, {"name": "TransicionesPantalla"}, {"name": "EstadosPantalla"}, {"name": "DisenoAngosto"}, {"name": "EnConstruccion"}, {"name": "Movimiento"}]} */
(function () {
  /* Ayudantes de las previews de Ícaro: icono procedural de instancia y busto de skin. */
  var TONOS = ['var(--surface-sunken)', 'var(--border)', 'var(--border-strong)', 'var(--text-muted)', 'var(--text)'];
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function siguiente(r) { r ^= r << 13; r >>>= 0; r ^= r >>> 17; r ^= r << 5; return r >>> 0; }
  /* Patrón 8 x 8 simétrico en tonos de tinta, derivado del nombre (FNV-1a + xorshift). */
  function instancia(el, nombre) {
    var r = hash(nombre) || 1, celdas = new Array(64);
    for (var y = 0; y < 8; y++) for (var x = 0; x < 4; x++) {
      r = siguiente(r); var t = r % 9; t = t < 3 ? 0 : t < 5 ? 1 : t < 7 ? 2 : t < 8 ? 3 : 4;
      if ((x === 0 || x === 3) && (y === 0 || y === 7)) t = 0;
      celdas[y * 8 + x] = t; celdas[y * 8 + 7 - x] = t;
    }
    el.classList.add('ic-pixel'); el.innerHTML = '';
    celdas.forEach(function (t) { var s = document.createElement('span'); s.style.background = TONOS[t]; el.appendChild(s); });
    el.setAttribute('role', 'img'); el.setAttribute('aria-label', 'Icono de ' + nombre);
  }
  /* Busto de mármol inventado: placeholder de skin en grises fijos. */
  var CARAS = {
    busto: ['hhhhhhhh', 'hhhhhhhh', 'hssssssh', 'ssssssss', 'sepssPes', 'sssnnsss', 'ssmmmmss', 'ssssssss'],
    barba: ['hhhhhhhh', 'hhhhhhhh', 'hssssssh', 'ssssssss', 'sepssPes', 'sssnnsss', 'bbmmmmbb', 'bbbbbbbb']
  };
  var GRISES = { h: '#2b2b2a', s: '#c9c9c4', e: '#f4f4f0', p: '#111111', P: '#111111', n: '#a3a39e', m: '#6e6e69', b: '#4a4a47' };
  function skin(el, variante) {
    var cara = CARAS[variante] || CARAS.busto;
    el.classList.add('ic-pixel'); el.innerHTML = '';
    cara.join('').split('').forEach(function (c) { var s = document.createElement('span'); s.style.background = GRISES[c]; el.appendChild(s); });
    el.setAttribute('role', 'img'); el.setAttribute('aria-label', 'Cabeza de skin');
  }

  /* Cuerpo completo 16 x 32 (vista frontal o espalda) para cuenta y estudio de skin. */
  var ROPA = { c: '#8a8a85', k: '#5c5c58', l: '#4a4a47', z: '#2b2b2a', t: '#2b2b2a', x: 'transparent' };
  function cuerpo(el, vista) {
    var cara = vista === 'espalda' ? ['hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh', 'hhhhhhhh'] : CARAS.busto;
    var filas = [];
    for (var y = 0; y < 32; y++) {
      var f = '';
      for (var x = 0; x < 16; x++) {
        var c = 'x';
        if (y < 8) { c = (x >= 4 && x < 12) ? cara[y][x - 4] : 'x'; }
        else if (y < 20) {
          if (x >= 4 && x < 12) c = y === 16 ? 'k' : 'c';
          else c = y < 11 ? 'c' : 's';
        } else if (x >= 4 && x < 12) { c = y >= 29 ? 'z' : 'l'; }
        f += c;
      }
      filas.push(f);
    }
    el.classList.add('ic-cuerpo'); el.innerHTML = '';
    filas.join('').split('').forEach(function (c) { var s = document.createElement('span'); s.style.background = GRISES[c] || ROPA[c]; el.appendChild(s); });
    el.setAttribute('role', 'img'); el.setAttribute('aria-label', 'Skin, vista ' + (vista || 'frontal'));
  }

  /* ---------------------------------------------------------------- Movimiento brutalista gótico */
  var REDUCIDO = W0().matchMedia && W0().matchMedia('(prefers-reduced-motion: reduce)').matches;
  function W0() { return window; }
  function reiniciar(el, clase) { el.classList.remove(clase); void el.offsetWidth; el.classList.add(clase); }
  /* Muro de bloques: cubre el contenedor con bloques y los retira en escalera diagonal. */
  function muro(cont, alCubrir, cols, filas) {
    cols = cols || 12; filas = filas || 6;
    if (REDUCIDO) { if (alCubrir) alCubrir(); cont.animate([{ opacity: .4 }, { opacity: 1 }], { duration: 120 }); return; }
    var m = document.createElement('div'); m.className = 'ic-muro';
    m.style.gridTemplateColumns = 'repeat(' + cols + ', 1fr)'; m.style.gridTemplateRows = 'repeat(' + filas + ', 1fr)';
    for (var y = 0; y < filas; y++) for (var x = 0; x < cols; x++) {
      var b = document.createElement('span'); b.dataset.d = x + y; m.appendChild(b);
    }
    if (getComputedStyle(cont).position === 'static') cont.style.position = 'relative';
    cont.appendChild(m);
    var max = cols + filas - 2, paso = 240 / (max + 4);
    m.querySelectorAll('span').forEach(function (b) {
      b.animate([{ transform: 'scale(0)' }, { transform: 'scale(1)' }], { duration: 1, delay: +b.dataset.d * paso * .5, fill: 'backwards', easing: 'steps(1, end)' });
    });
    setTimeout(function () {
      if (alCubrir) alCubrir();
      m.querySelectorAll('span').forEach(function (b) {
        b.animate([{ transform: 'none', opacity: 1 }, { transform: 'translateY(8px)', opacity: 0 }], { duration: 90, delay: +b.dataset.d * paso, fill: 'forwards', easing: 'steps(2, end)' });
      });
      setTimeout(function () { m.remove(); }, max * paso + 120);
    }, max * paso * .5 + 40);
  }
  /* Prensa: imprime una imagen de arriba abajo. */
  function prensa(el) { if (!el) return; reiniciar(el, 'is-imprimiendo'); el.classList.add('ic-prensa'); setTimeout(function () { el.classList.remove('is-imprimiendo'); }, 480); }
  function losa(el) { reiniciar(el, 'ic-losa'); }
  function colocar(el) { reiniciar(el, 'ic-colocar'); }
  function rastrillo(el, abrir) { el.classList.remove('is-abriendo', 'is-cerrando'); void el.offsetWidth; el.classList.add(abrir ? 'is-abriendo' : 'is-cerrando'); }
  /* Picar: grietas de 10 etapas en una rejilla de 16 x 16, como al romper un bloque. */
  function grietas(semilla) {
    var r = hash(semilla) || 7, pts = [], vis = {}, frentes = [[8, 8]];
    function rnd() { r = siguiente(r); return r / 4294967296; }
    while (pts.length < 120 && frentes.length) {
      var i = Math.floor(rnd() * frentes.length), f = frentes[i];
      var d = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]][Math.floor(rnd() * 8)];
      var n = [f[0] + d[0], f[1] + d[1]];
      if (n[0] < 0 || n[1] < 0 || n[0] > 15 || n[1] > 15) { frentes.splice(i, 1); continue; }
      var k = n[0] + ',' + n[1]; if (vis[k]) { if (rnd() < .3) frentes.splice(i, 1); continue; }
      vis[k] = 1; pts.push(n); frentes.push(n); if (frentes.length > 5) frentes.shift();
    }
    return pts;
  }
  function picar(cont, opciones) {
    opciones = opciones || {};
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 16 16'); svg.setAttribute('preserveAspectRatio', 'none'); svg.setAttribute('class', 'ic-grietas'); svg.setAttribute('aria-hidden', 'true');
    var pts = grietas(opciones.semilla || 'icaro'), rects = pts.map(function (p, i) {
      var q = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      q.setAttribute('x', p[0]); q.setAttribute('y', p[1]); q.setAttribute('width', 1); q.setAttribute('height', 1);
      if (i % 5 === 3) q.setAttribute('class', 'luz'); q.style.display = 'none'; svg.appendChild(q); return q;
    });
    cont.classList.add('ic-picar'); cont.appendChild(svg);
    var etapa = 0;
    return {
      etapa: function (e) { etapa = Math.max(0, Math.min(10, e)); var n = Math.round(rects.length * etapa / 10); rects.forEach(function (q, i) { q.style.display = i < n ? '' : 'none'; }); },
      romper: function (alTerminar) {
        var base = cont.getBoundingClientRect(), padre = cont.offsetParent || document.body, o = padre.getBoundingClientRect();
        var cols = 8, filas = 6, w = base.width / cols, h = base.height / filas;
        if (!REDUCIDO) for (var y = 0; y < filas; y++) for (var x = 0; x < cols; x++) {
          var b = document.createElement('span'); b.className = 'ic-escombro';
          var tam = Math.max(6, Math.round(Math.min(w, h) * (.25 + ((x * 7 + y * 3) % 5) * .08)));
          b.style.cssText = 'left:' + (base.left - o.left + x * w + w / 2 - tam / 2) + 'px;top:' + (base.top - o.top + y * h + h / 2 - tam / 2) + 'px;width:' + tam + 'px;height:' + tam + 'px;background:' + ((x + y) % 3 ? 'var(--text-muted)' : 'var(--text)');
          padre.appendChild(b);
          var dx = (x - cols / 2) * (6 + (y % 3) * 4), caida = 140 + (filas - y) * 30 + (x % 3) * 20;
          b.animate([{ transform: 'translate(0,0)', opacity: 1 }, { transform: 'translate(' + dx * .4 + 'px,-14px)', opacity: 1, offset: .2 }, { transform: 'translate(' + dx + 'px,' + caida + 'px)', opacity: 0 }],
            { duration: 620 + (x % 4) * 60, easing: 'cubic-bezier(0.55, 0, 1, 0.45)', fill: 'forwards' }).onfinish = (function (el) { return function () { el.remove(); }; })(b);
        }
        cont.animate([{ opacity: 1 }, { opacity: 0 }], { duration: REDUCIDO ? 120 : 60, fill: 'forwards', easing: 'steps(1, end)' });
        setTimeout(function () { if (alTerminar) alTerminar(); }, REDUCIDO ? 140 : 720);
      }
    };
  }
  function montar(raiz) {
    raiz = raiz || document;
    raiz.querySelectorAll('[data-instancia]').forEach(function (e) { instancia(e, e.getAttribute('data-instancia')); });
    raiz.querySelectorAll('[data-skin]').forEach(function (e) { skin(e, e.getAttribute('data-skin')); });
    raiz.querySelectorAll('[data-cuerpo]').forEach(function (e) { cuerpo(e, e.getAttribute('data-cuerpo')); });
  }
  var W = window; W.Icaro = W.Icaro || {};
  W.Icaro.instancia = instancia; W.Icaro.skin = skin; W.Icaro.montar = montar; W.Icaro.cuerpo = cuerpo; W.Icaro.muro = muro; W.Icaro.prensa = prensa; W.Icaro.losa = losa; W.Icaro.colocar = colocar; W.Icaro.rastrillo = rastrillo; W.Icaro.picar = picar; W.Icaro.hash = hash;
})();

/* Visor 3D de skin (CSS 3D, sin dependencias) y skins de ejemplo inventadas. Giros solo en pasos de 90 grados. */
(function () {
  var W = window; W.Icaro = W.Icaro || {};
  var UV = { cabeza: [0, 0, 8, 8, 8], sombrero: [32, 0, 8, 8, 8], cuerpo: [16, 16, 8, 12, 4], chaqueta: [16, 32, 8, 12, 4],
    bD: [40, 16, 4, 12, 4], bI: [32, 48, 4, 12, 4], mD: [40, 32, 4, 12, 4], mI: [48, 48, 4, 12, 4],
    pD: [0, 16, 4, 12, 4], pI: [16, 48, 4, 12, 4], tD: [0, 32, 4, 12, 4], tI: [0, 48, 4, 12, 4], capa: [0, 0, 10, 16, 1] };
  var LUZ = { frente: 1, espalda: .74, der: .84, izq: .84, arriba: 1.1, abajo: .6 };
  var RED = W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function caras(uv, a) {
    var u = uv[0], v = uv[1], w = a || uv[2], h = uv[3], d = uv[4];
    return { frente: [u + d, v + d, w, h], espalda: [u + 2 * d + w, v + d, w, h], der: [u, v + d, d, h], izq: [u + d + w, v + d, d, h], arriba: [u + d, v, w, d], abajo: [u + d + w, v, w, d] };
  }
  function caja(tex, uv, S, a, infl, espejo) {
    var w = a || uv[2], h = uv[3], d = uv[4], Wp = w * S + infl * 2, H = h * S + infl * 2, D = d * S + infl * 2, c = caras(uv, a);
    if (espejo) { var t = c.der; c.der = c.izq; c.izq = t; }
    var tr = { frente: [Wp, H, 'translateZ(' + D / 2 + 'px)'], espalda: [Wp, H, 'rotateY(180deg) translateZ(' + D / 2 + 'px)'],
      der: [D, H, 'rotateY(-90deg) translateZ(' + Wp / 2 + 'px)'], izq: [D, H, 'rotateY(90deg) translateZ(' + Wp / 2 + 'px)'],
      arriba: [Wp, D, 'rotateX(90deg) translateZ(' + H / 2 + 'px)'], abajo: [Wp, D, 'rotateX(-90deg) translateZ(' + H / 2 + 'px)'] };
    var b = document.createElement('div'); b.className = 'ic-v-caja';
    Object.keys(tr).forEach(function (k) {
      var s = c[k], cv = document.createElement('canvas'); cv.width = s[2]; cv.height = s[3];
      var g = cv.getContext('2d'); g.imageSmoothingEnabled = false;
      if (espejo) { g.translate(s[2], 0); g.scale(-1, 1); }
      g.drawImage(tex, s[0], s[1], s[2], s[3], 0, 0, s[2], s[3]);
      var f = tr[k]; cv.className = 'ic-v-cara';
      cv.style.cssText = 'width:' + f[0] + 'px;height:' + f[1] + 'px;left:' + (-f[0] / 2) + 'px;top:' + (-f[1] / 2) + 'px;transform:' + f[2] + ';filter:brightness(' + LUZ[k] + ')';
      b.appendChild(cv);
    });
    return b;
  }
  function grupo(x, y, z, hijo, dy) {
    var g = document.createElement('div'); g.className = 'ic-v-grupo'; g.style.transform = 'translate3d(' + x + 'px,' + y + 'px,' + z + 'px)';
    var i = document.createElement('div'); i.className = 'ic-v-grupo'; i.style.transform = 'translateY(' + (dy || 0) + 'px)';
    [].concat(hijo).forEach(function (h) { i.appendChild(h); }); g.appendChild(i); return g;
  }
  var NOMBRES = { 0: 'Frente', 90: 'Lado derecho', 180: 'Espalda', 270: 'Lado izquierdo' };
  function visor(el, o) {
    o = Object.assign({ tex: null, modelo: 'clasico', capas: { sombrero: true, chaqueta: true, mangas: true, pantalones: true }, capa: null,
      vista: '3d', zoom: 'cuerpo', yaw: 0, caminar: false, alGirar: null }, o || {});
    el.classList.add('ic-visor'); el.innerHTML = '';
    var escena = document.createElement('div'); escena.className = 'ic-visor__escena'; el.appendChild(escena);
    var miembros = [], anims = [];
    function S() { return Math.max(4, Math.floor(Math.min(el.clientHeight / 38, el.clientWidth / 22))); }
    function armar() {
      escena.innerHTML = ''; miembros = []; anims.forEach(function (a) { a.cancel(); }); anims = [];
      if (!o.tex) { el.classList.add('is-vacio'); return; }
      el.classList.remove('is-vacio');
      var s = S(), t = o.tex, viejo = t.height === 32, a = o.modelo === 'delgado' ? 3 : 4, c = o.capas, inf = Math.max(1, s * .5);
      function par(base, capa, encendida, espejoDe, capaDe) {
        var hijos = [caja(t, UV[viejo && espejoDe ? espejoDe : base], s, base[0] === 'b' ? a : 0, 0, viejo && !!espejoDe)];
        if (encendida && !(viejo && capaDe)) hijos.push(caja(t, UV[capa], s, base[0] === 'b' ? a : 0, inf, false));
        return hijos;
      }
      escena.appendChild(grupo(0, -12 * s, 0, par('cabeza', 'sombrero', c.sombrero)));
      escena.appendChild(grupo(0, -2 * s, 0, viejo ? [caja(t, UV.cuerpo, s, 0, 0)] : par('cuerpo', 'chaqueta', c.chaqueta)));
      var bD = grupo(-(4 + a / 2) * s, -8 * s, 0, par('bD', 'mD', c.mangas), 6 * s), bI = grupo((4 + a / 2) * s, -8 * s, 0, par('bI', 'mI', c.mangas, 'bD', true), 6 * s);
      var pD = grupo(-2 * s, 4 * s, 0, par('pD', 'tD', c.pantalones), 6 * s), pI = grupo(2 * s, 4 * s, 0, par('pI', 'tI', c.pantalones, 'pD', true), 6 * s);
      [bD, bI, pD, pI].forEach(function (m) { escena.appendChild(m); }); miembros = [bD, bI, pD, pI];
      if (o.capa) {
        var cp = caja(o.capa, UV.capa, s, 0, 0); var g = grupo(0, -8 * s, -3 * s, cp, 8 * s); g.firstChild.style.transform = 'rotateX(-10deg) translateY(' + 8 * s + 'px)';
        g.firstChild.style.transformOrigin = '0 0'; escena.appendChild(g);
      }
      animar();
    }
    function animar() {
      anims.forEach(function (x) { x.cancel(); }); anims = [];
      if (!o.caminar || RED || !miembros.length) return;
      miembros.forEach(function (m, i) {
        var signo = (i === 0 || i === 3) ? 1 : -1, base = m.style.transform;
        anims.push(m.animate([{ transform: base + ' rotateX(' + 28 * signo + 'deg)' }, { transform: base + ' rotateX(' + -28 * signo + 'deg)' }],
          { duration: 520, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' }));
      });
    }
    function pose() {
      var s = S(), busto = o.zoom === 'busto', z = busto ? 2.1 : 1, dy = busto ? 12 * s * z : 0;
      escena.style.transform = 'translateY(' + dy + 'px) scale(' + z + ') rotateX(' + (o.vista === '3d' ? -14 : 0) + 'deg) rotateY(' + o.yaw + 'deg)';
      el.classList.toggle('is-plano', o.vista !== '3d');
      var n = ((o.yaw % 360) + 360) % 360; el.setAttribute('aria-label', 'Vista de la skin: ' + NOMBRES[n]);
      if (o.alGirar) o.alGirar(n, NOMBRES[n]);
    }
    /* arrastre: solo cambia de a 90 grados al pasar el umbral */
    var x0 = null, paso = 0;
    el.addEventListener('pointerdown', function (e) { x0 = e.clientX; paso = 0; el.setPointerCapture(e.pointerId); el.classList.add('is-arrastrando'); });
    el.addEventListener('pointermove', function (e) { if (x0 === null) return; var n = Math.trunc((e.clientX - x0) / 70); if (n !== paso) { api.girar(n > paso ? 1 : -1); paso = n; } });
    function soltar() { x0 = null; el.classList.remove('is-arrastrando'); }
    el.addEventListener('pointerup', soltar); el.addEventListener('pointercancel', soltar);
    el.tabIndex = 0; el.setAttribute('role', 'img');
    el.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft') { api.girar(-1); e.preventDefault(); } if (e.key === 'ArrowRight') { api.girar(1); e.preventDefault(); } });
    var api = {
      set: function (p) { var re = ['tex', 'modelo', 'capas', 'capa'].some(function (k) { return k in p; }); Object.assign(o, p); if (re) armar(); else if ('caminar' in p) animar(); pose(); return api; },
      girar: function (d) { o.yaw += 90 * d; pose(); return api; },
      ir: function (deg) { var n = ((o.yaw % 360) + 360) % 360, dif = ((deg - n + 540) % 360) - 180; o.yaw += dif; pose(); return api; },
      estado: function () { return o; }
    };
    armar(); pose();
    if (W.ResizeObserver) { var t0; new ResizeObserver(function () { clearTimeout(t0); t0 = setTimeout(function () { armar(); pose(); }, 80); }).observe(el); }
    return api;
  }
  /* Skins de ejemplo: personajes inventados pintados por código, en grises. */
  function ruido(x, y, k) { var h = Math.imul(x * 73856093 ^ y * 19349663 ^ k * 83492791, 2654435761) >>> 0; return (h % 17) - 8; }
  function gris(v, n) { v = Math.max(0, Math.min(255, v + (n || 0))); return 'rgb(' + v + ',' + v + ',' + (v - 2 < 0 ? 0 : v - 2) + ')'; }
  function pintar(g, uv, a, fn, k) {
    var c = caras(uv, a);
    Object.keys(c).forEach(function (cara) { var r = c[cara];
      for (var y = 0; y < r[3]; y++) for (var x = 0; x < r[2]; x++) { var v = fn(cara, x, y, r[2], r[3]); if (v == null) continue; g.fillStyle = gris(v, ruido(r[0] + x, r[1] + y, k)); g.fillRect(r[0] + x, r[1] + y, 1, 1); } });
  }
  function skinEjemplo(variante, modelo) {
    var p = [{ piel: 196, pelo: 44, camisa: 120, chaq: 72, pan: 58, bota: 28 }, { piel: 210, pelo: 150, camisa: 88, chaq: 168, pan: 40, bota: 60 },
      { piel: 170, pelo: 24, camisa: 200, chaq: 96, pan: 110, bota: 36 }, { piel: 186, pelo: 96, camisa: 60, chaq: 40, pan: 140, bota: 20 }][(variante || 0) % 4];
    var a = modelo === 'delgado' ? 3 : 4, k = (variante || 0) + 1;
    var cv = document.createElement('canvas'); cv.width = cv.height = 64; var g = cv.getContext('2d');
    pintar(g, UV.cabeza, 0, function (c, x, y) {
      if (c === 'arriba') return p.pelo; if (c === 'abajo') return p.piel - 30;
      if (c === 'frente') { if (y < 2) return p.pelo; if (y === 4 && (x === 1 || x === 6)) return 240; if (y === 4 && (x === 2 || x === 5)) return 20; if (y === 6 && x > 2 && x < 5) return p.piel - 60; if (y === 5 && (x === 3 || x === 4)) return p.piel - 24; return p.piel; }
      if (c === 'espalda') return y < 7 ? p.pelo : p.piel - 10; return y < 3 || (y < 5 && (c === 'der' ? x < 3 : x > 4)) ? p.pelo : p.piel - 8; }, k);
    pintar(g, UV.sombrero, 0, function (c, x, y) { if (c === 'arriba') return p.pelo + 12; if (c === 'frente') return y === 0 && x % 3 !== 1 ? p.pelo + 8 : null;
      if (c === 'espalda') return y < 6 ? p.pelo + 8 : null; if (c === 'der' || c === 'izq') return y < 2 ? p.pelo + 8 : null; return null; }, k + 10);
    pintar(g, UV.cuerpo, 0, function (c, x, y) { if (c === 'arriba') return p.camisa; if (c === 'abajo') return p.pan;
      if (y >= 10) return p.pan; if (y === 9) return 30; if (c === 'frente' && y < 2 && x > 2 && x < 5) return p.piel - 10; if (c === 'frente' && (x === 3 || x === 4) && y > 1 && y % 3 === 0) return p.camisa - 40; return p.camisa; }, k + 20);
    pintar(g, UV.chaqueta, 0, function (c, x, y) { if (y > 9) return null; if (c === 'frente') return (x < 2 || x > 5) ? p.chaq : (y < 1 ? p.chaq + 20 : null);
      if (c === 'abajo') return null; return p.chaq - (c === 'espalda' && y === 4 ? 16 : 0); }, k + 30);
    ['bD', 'bI'].forEach(function (b, i) { pintar(g, UV[b], a, function (c, x, y) { if (c === 'abajo') return p.piel - 20; if (c === 'arriba') return p.camisa; return y < 9 ? p.camisa - 6 : p.piel; }, k + 40 + i); });
    ['mD', 'mI'].forEach(function (b, i) { pintar(g, UV[b], a, function (c, x, y) { if (c === 'abajo' || c === 'arriba') return c === 'arriba' ? p.chaq : null; return y < 7 ? p.chaq : (y === 7 ? p.chaq + 30 : null); }, k + 50 + i); });
    ['pD', 'pI'].forEach(function (b, i) { pintar(g, UV[b], 0, function (c, x, y) { if (c === 'abajo') return p.bota - 10; if (c === 'arriba') return p.pan; return y < 9 ? p.pan : p.bota; }, k + 60 + i); });
    ['tD', 'tI'].forEach(function (b, i) { pintar(g, UV[b], 0, function (c, x, y) { if (c !== 'frente') return null; return (y === 5 || y === 6) && x > 0 && x < 3 ? p.pan + 26 : null; }, k + 70 + i); });
    return cv;
  }
  function capaEjemplo(tipo) {
    var cv = document.createElement('canvas'); cv.width = 64; cv.height = 32; var g = cv.getContext('2d');
    pintar(g, UV.capa, 0, function (c, x, y) {
      if (tipo === 'lineas') return (y % 4 === 0) ? 230 : 70; if (tipo === 'damero') return ((x >> 1) + (y >> 1)) % 2 ? 200 : 90;
      if (tipo === 'borde') return (x === 0 || x === 9 || y === 0 || y === 15) ? 220 : (y > 5 && y < 10 && x > 2 && x < 7 ? 220 : 50); return 110; }, tipo.length);
    return cv;
  }
  function cara(tex, el) {
    var c = document.createElement('canvas'); c.width = c.height = 8; var g = c.getContext('2d'); g.imageSmoothingEnabled = false;
    g.drawImage(tex, 8, 8, 8, 8, 0, 0, 8, 8); if (tex.height === 64 || tex.height === undefined || tex.height >= 64) g.drawImage(tex, 40, 8, 8, 8, 0, 0, 8, 8);
    c.className = 'ic-v-retrato'; if (el) { el.innerHTML = ''; el.appendChild(c); } return c;
  }
  W.Icaro.visor = visor; W.Icaro.skinEjemplo = skinEjemplo; W.Icaro.capaEjemplo = capaEjemplo; W.Icaro.caraSkin = cara; W.Icaro.UV = UV;
})();

/* Grabado en ASCII: lee el formato .ascii (niveles + bordes), lo dibuja como texto y lo anima con tope de cuadros. */
(function () {
  var W = window; W.Icaro = W.Icaro || {};
  var RAMPA = [' ', '.`', '\',', ':-', '~^', ';!', '=+', '*v', 'ic', 'xn', 'tf', 'oy', 'ea', '42', '%m', '@M'];
  var RED = W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var HEX = '0123456789abcdef';
  function leer(txt, chico) {
    var bloques = txt.replace(/\r/g, '').split('\n===\n'), b = (chico && bloques[1]) ? bloques[1] : bloques[0];
    var l = b.split('\n'); if (/^ICARO-ASCII/.test(l[0])) l.shift();
    var dim = l.shift().split(' '), c = +dim[0], f = +dim[1];
    var niv = new Uint8Array(c * f), bor = new Array(c * f);
    for (var y = 0; y < f; y++) for (var x = 0; x < c; x++) { niv[y * c + x] = HEX.indexOf(l[y][x]); bor[y * c + x] = (l[f + 1 + y] || '')[x] || ' '; }
    return { c: c, f: f, niv: niv, bor: bor };
  }
  function ruido(i, k) { var h = Math.imul(i ^ (k * 2654435761), 2246822519) >>> 0; h ^= h >>> 13; return (Math.imul(h, 3266489917) >>> 0) / 4294967296; }
  function ascii(el, txt, o) {
    o = Object.assign({ chico: false, animar: true, fps: 10, cursor: true, encajar: 'contener' }, o || {});
    var d = leer(txt, o.chico), pre = document.createElement('pre');
    pre.className = 'ic-ascii__texto'; pre.setAttribute('aria-hidden', 'true');
    el.classList.add('ic-ascii'); el.innerHTML = ''; el.appendChild(pre);
    var t = 0, entrada = 1, cur = null, timer = null, visible = true, pausado = false, ultimo = 0, raf = null, cuadros = 0;
    function medir() {
      var w = el.clientWidth, h = el.clientHeight, fs = o.encajar === 'cubrir' ? Math.max(w / (d.c * .75), h / (d.f * 1.25)) : Math.min(w / (d.c * .75), h / (d.f * 1.25));
      pre.style.fontSize = Math.max(2, fs) + 'px';
    }
    function glifo(i, nivel, alt) { if (d.bor[i] !== ' ' && nivel > 2 && !alt) return d.bor[i]; var r = RAMPA[Math.max(0, Math.min(15, nivel))]; return r[alt ? 1 : 0] || r[0]; }
    function pintar() {
      var c = d.c, f = d.f, out = new Array(f), fr = Math.floor(t);
      var corte = entrada < 1 ? Math.floor(entrada * 4) / 4 * f : f; /* barrido de imprenta en 4 pasos */
      for (var y = 0; y < f; y++) {
        var s = '';
        if (y > corte + 2) { out[y] = ''; continue; }
        for (var x = 0; x < c; x++) {
          var i = y * c + x, n = d.niv[i], alt = false;
          if (entrada < 1 && y > corte - 3) { n = Math.floor(ruido(i, fr) * 16) * (n > 0 ? 1 : 0); alt = true; }
          else if (o.animar && !RED) {
            var ola = Math.sin((x * .5 + y * .9) / 7 - t * .55) + Math.sin((x * .9 - y * .4) / 11 + t * .35);
            if (ola > 1.55 && n > 1) { n = Math.min(15, n + 1); alt = ruido(i, fr) > .5; }
            if (cur) { var dx = (x - cur[0]) * .6, dy = y - cur[1], q = dx * dx + dy * dy; if (q < 36 && n > 0) { n = Math.min(15, n + 3 - Math.floor(q / 14)); alt = ruido(i, fr + 7) > .6; } }
          }
          s += glifo(i, n, alt);
        }
        out[y] = s;
      }
      pre.textContent = out.join('\n'); cuadros++;
    }
    function paso(ahora) {
      raf = null;
      if (pausado || !visible) return;
      if (ahora - ultimo >= 1000 / o.fps) { ultimo = ahora; t += 1; if (entrada < 1) entrada = Math.min(1, entrada + 1 / (o.fps * .8)); pintar(); }
      if (entrada < 1 || (o.animar && !RED)) raf = requestAnimationFrame(paso);
    }
    function seguir() { if (!raf && !pausado && visible) raf = requestAnimationFrame(paso); }
    el.addEventListener('pointermove', function (e) { if (!o.cursor || !o.animar) return; var r = pre.getBoundingClientRect(); cur = [(e.clientX - r.left) / r.width * d.c, (e.clientY - r.top) / r.height * d.f]; });
    el.addEventListener('pointerleave', function () { cur = null; });
    if (W.IntersectionObserver) new IntersectionObserver(function (es) { visible = es[0].isIntersecting; if (visible) seguir(); }).observe(el);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) seguir(); });
    if (W.ResizeObserver) new ResizeObserver(medir).observe(el);
    var api = {
      set: function (p) { if (p.animar === false) entrada = 1; if ('txt' in p || 'chico' in p) { if (p.txt) txt = p.txt; Object.assign(o, p); d = leer(txt, o.chico); medir(); } else Object.assign(o, p); pintar(); seguir(); return api; },
      entrar: function () { entrada = RED ? 1 : 0; seguir(); if (RED) pintar(); return api; },
      pausar: function (v) { pausado = v; if (v && entrada < 1) { entrada = 1; pintar(); } if (!v) seguir(); return api; },
      celdas: function () { return d.c * d.f; }, dims: function () { return [d.c, d.f]; }, cuadros: function () { return cuadros; }
    };
    medir(); if (RED) { entrada = 1; pintar(); } else { entrada = 0; pintar(); seguir(); }
    return api;
  }
  W.Icaro.ascii = ascii; W.Icaro.leerAscii = leer;
})();

/* Estados de ejemplo: botones [data-demo-e] muestran solo los [data-e] que incluyen ese estado (sin tocar raíces anidadas). */
(function () {
  var W = window; W.Icaro = W.Icaro || {};
  W.Icaro.estados = function (root) {
    if (!root) return function () {};
    var bs = [].filter.call(root.querySelectorAll('[data-demo-e]'), function (b) { return b.closest('.ic-estados') === root; });
    function ir(e) {
      root.dataset.estado = e;
      bs.forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.demoE === e)); });
      root.querySelectorAll('[data-e]').forEach(function (x) { if (x.closest('.ic-estados') !== root) return; x.hidden = x.dataset.e.split(' ').indexOf(e) < 0; });
    }
    bs.forEach(function (b) { b.addEventListener('click', function () { ir(b.dataset.demoE); }); });
    var ini = bs.filter(function (b) { return b.getAttribute('aria-pressed') === 'true'; })[0] || bs[0]; if (ini) ir(ini.dataset.demoE);
    return ir;
  };
})();
