# CierreConTransferencias

Qué hacer cuando el anfitrión cierra Ícaro o deja de compartir mientras hay transferencias en curso. Nunca se corta en silencio: se muestra quién está recibiendo y se dan opciones con su consecuencia.

## Variantes

| Al | Opciones | Por defecto |
| --- | --- | --- |
| Cerrar Ícaro | **Seguir en segundo plano**: Ícaro queda en la bandeja hasta que terminen y luego se cierra. **Cerrar ahora**: se cortan; los invitados retoman cuando vuelvas a compartir | Seguir en segundo plano |
| Dejar de compartir | **Esperar a que terminen**: no acepta nuevas descargas y se detiene al terminar. **Detener ahora**: se cortan 2 transferencias y se revocan 3 sesiones | Esperar a que terminen |

## Reglas

- Lista de transferencias con nombre, fase y porcentaje.
- Las opciones son tarjetas de radio con título y consecuencia; el botón principal cambia de texto según la elegida.
- "Cerrar ahora" y "Detener ahora" llevan el botón en `peligro`.
- Si no hay transferencias activas, no se muestra este diálogo: cerrar o detener ocurre de inmediato (detener sigue pidiendo confirmación en AccesosCompartidos).
- "No volver a preguntar" no existe aquí: cortar descargas ajenas siempre se confirma.

## En iced

`window::close_requests()` intercepta el cierre; si `transferencias_activas > 0` muestra este diálogo y, con Seguir en segundo plano, oculta la ventana y deja vivo el `Subscription` del servidor hasta que la cola quede vacía.
