# InvitacionCompartir

El código que el anfitrión envía para que alguien acepte su instancia compartida. De un solo uso y con caducidad.

## Código

- 12 caracteres en tres grupos de 4 (`7QKM-4XPT-R2C9`), sin letras que se confunden (O/0, I/1/L). Celdas de 36 × 48 con borde de 2 px y `mono` de 24 px.
- Copiar código copia el texto con guiones y cambia a "Copiado" durante 2 s.
- **Caducidad**: 24 h por defecto (configurable a 1 h, 24 h o 7 días). Se muestra el tiempo que queda en `mono-sm`.
- **Generar otro** anula el código anterior en el acto.

## Estados

| Estado | Insignia | Texto | Acción |
| --- | --- | --- | --- |
| Generando | contorno | Celdas en esqueleto | — |
| Vigente | exito | "Caduca en 23 h 41 min · sirve para una sola persona" | Copiar, Revocar, Generar otro |
| Vencida | alerta | "Venció hace 2 h y nadie la usó"; celdas rayadas | Generar otra invitación |
| Aceptada | info | "Forjador la aceptó hace 5 min" | Generar otra invitación |
| Revocada | error | "La revocaste. Este código ya no sirve"; celdas rayadas | Generar otra invitación |

## En iced

El código sale de 60 bits aleatorios codificados en Crockford base32. El anfitrión guarda solo su hash y la caducidad; al aceptarse se marca como consumido.
