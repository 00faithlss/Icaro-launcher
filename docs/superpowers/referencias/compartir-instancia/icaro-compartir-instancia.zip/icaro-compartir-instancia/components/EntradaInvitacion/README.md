# EntradaInvitacion

Donde el invitado pega el código. Explica sin tecnicismos por qué un código no sirve y qué hacer. Un puente colgante entre bóvedas: hay que cruzarlo para llegar al otro lado.

## Campo

- Un solo campo `mono` de 22 px con máscara `XXXX-XXXX-XXXX`: acepta el código con o sin guiones, en minúsculas o con espacios, y lo normaliza.
- **Pegar** lee el portapapeles. Al completar los 12 caracteres se valida solo.
- Si la invitación llega como enlace `icaro://invitacion/7QKM-4XPT-R2C9`, el campo aparece ya lleno.

## Mensajes

| Caso | Texto |
| --- | --- |
| Inválido | "Este código no existe. Revisa que esté completo: son 12 caracteres, como 7QKM-4XPT-R2C9." |
| Vencido | "Esta invitación venció el 04-11 a las 22:10. Pide a Mineral_7 que genere otra." |
| Consumido | "Esta invitación ya se usó. Cada una sirve para una sola persona: pide otra." |
| Anfitrión inaccesible | Ver ResumenConexion: el código puede ser bueno, pero no se pudo comprobar |

Los errores van debajo del campo con `ic-campo.is-error` y `aria-live`.

## En iced

`text_input` con `on_input` que normaliza; la validación pide al anfitrión (vía el relé) el estado del código y su clave pública, que pasa a IdentidadAnfitrion.
