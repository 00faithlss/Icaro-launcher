# ConfirmarJarPropios

Autorización expresa para transferir `.jar` que no están en ninguna plataforma. Ícaro no puede revisar qué hacen esos archivos, así que no los envía por defecto: el anfitrión tiene que marcar la casilla de permiso y pulsar Autorizar.

## Reglas

- Lista cada archivo con nombre, tamaño, inicio y fin del SHA-256 y su carpeta.
- La casilla "Tengo permiso para compartir estos archivos y confío en su contenido" empieza desmarcada; Autorizar y compartir queda deshabilitado hasta marcarla.
- **Excluirlos y continuar** comparte sin ellos (quedan como Excluidos con motivo "Sin autorizar").
- La autorización vale para esa revisión y esos hashes: si un archivo cambia, se vuelve a pedir.
- Del lado del invitado, estos archivos aparecen marcados como "Del anfitrión" en RevisionSincronizacion.

## En iced

`checkbox` ligado a `autorizado: bool`; el botón principal es `button(..).on_press_maybe(autorizado.then_some(Message::Autorizar))`. Los hashes autorizados se guardan junto a la revisión.
