# RevisionSincronizacion

Qué va a cambiar en la instancia antes de tocarla: altas, actualizaciones, retiradas, conflictos y lo que se conserva. Reutiliza las filas `ic-diff` de SincronizarMods y suma conflictos y contenido conservado.

## Filas

| Marca | Tipo | Ejemplo |
| --- | --- | --- |
| `+` exito | Alta | Create 0.5.1j · 18,2 MB |
| `~` info | Actualización | Lithium 0.14.3 → 0.14.5 |
| `−` error | Retirada | Better Combat: "Mineral_7 lo quitó" |
| `!` alerta | Conflicto | Un archivo que cambiaste tú y que también cambió el anfitrión; se elige Del anfitrión o Conservar la mía |
| `=` contorno | Conservado | Tus mods solo de cliente y los archivos que no vienen del anfitrión |

Los archivos propios del anfitrión llevan la insignia "Del anfitrión".

## Estados

| Estado | Qué se ve | Botón principal |
| --- | --- | --- |
| Revisando | Spinner con "Comparando con la revisión 7" | Deshabilitado |
| Sin cambios | Aviso `exito` "Ya está al día con la revisión 7" | Jugar |
| Con diferencias | Resumen y filas | Sincronizar |
| Con conflictos | Bloque de conflictos primero | "Resuelve 2 conflictos", hasta elegir en todos |

## En iced

Diff por hash entre el manifiesto de la revisión y la instancia; los conflictos salen de comparar contra la última revisión aplicada (base de tres vías).
