# IdentidadAnfitrion

Antes de recibir nada, el invitado ve de quién viene: nombre del anfitrión, instancia y revisión que ofrece, y su **huella**, la identidad de su equipo. La huella se compara de palabra con la que el anfitrión ve en PanelPublicacion.

## Huella

- 24 caracteres hexadecimales en seis grupos de 4, `mono` de 20 px: `4F2A 91C0 7B3E D5A8 0C61 E2F9`.
- Al lado, un **sello** de 8 × 8 píxeles generado de la misma huella (simétrico, como un icono de instancia): dos huellas distintas dan sellos que se ven distintos a simple vista.
- Copiar huella.

## Estados

| Estado | Aviso | Acciones |
| --- | --- | --- |
| Primera vez | `info`: "Primera vez que aceptas de este equipo. Confirma la huella con Mineral_7 por otro medio (Discord, en persona)." | No es quien esperaba · Confiar y continuar |
| Ya conocido | `exito`: "Ya aceptaste de este equipo el 02-11. La huella coincide." | Continuar |
| Huella distinta | `error`: "Este equipo dice ser Mineral_7, pero su huella no es la que guardaste el 02-11. Puede ser un equipo nuevo o alguien haciéndose pasar por él." | Cancelar (principal) · Confiar en la nueva huella (fantasma de peligro, con casilla de confirmación) |

## En iced

La huella son los primeros 12 bytes del SHA-256 de la clave pública Ed25519 del anfitrión. Ícaro guarda las huellas aceptadas (`known_hosts.json`) y compara en cada conexión.
