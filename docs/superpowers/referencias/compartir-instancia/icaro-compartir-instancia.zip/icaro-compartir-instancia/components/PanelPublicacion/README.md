# PanelPublicacion

La vista del anfitrión mientras comparte: qué instancia, qué revisión está vigente, si está disponible para los invitados, las transferencias en curso, la invitación y los accesos. Vive en Servidores, arriba de la lista, y se abre a pantalla completa desde "Ver publicación".

## Cabecera

Icono y nombre de la instancia, Minecraft y loader, y la insignia de estado. Debajo, tres datos:

| Dato | Ejemplo |
| --- | --- |
| Revisión vigente | `Revisión 7 · 05-11 21:14 · a3f9 c021` |
| Disponibilidad | "Disponible · 2 de 3 en línea", "Pausada: Ícaro en segundo plano", "Detenida" |
| Transferencias | "1 activa · 412 MB por enviar" |

Tu huella como anfitrión va en `mono` con Copiar, para que el invitado la compare.

## Estados

| Estado | Qué cambia |
| --- | --- |
| Preparando | Barra con "Preparando la revisión 7 · 38 %"; la invitación espera |
| Compartiendo | Todo activo |
| Actualizando revisión | Aviso `info` "Hay cambios desde la revisión 7: 2 mods actualizados, 1 agregado" con Publicar revisión 8; mientras prepara, la 7 sigue disponible |
| Detenido | Insignia contorno; invitación y accesos vacíos; botón Volver a compartir |
| Error | Aviso `error` con el motivo y Reintentar; la revisión anterior sigue vigente |

## En iced

Estado `Publicacion { instancia, revision, disponibilidad, transferencias, invitacion, sesiones }` en la sección Servidores; el servidor de sincronización corre en una `Subscription` propia que emite eventos de conexión y transferencia.
