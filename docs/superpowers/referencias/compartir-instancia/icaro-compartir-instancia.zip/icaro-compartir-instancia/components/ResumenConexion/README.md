# ResumenConexion

Tres cosas distintas que antes se mezclaban en un solo "conectado": si el **anfitrión** está disponible, si la **sincronización** tiene conexión y si hay **acceso al juego**. Poder sincronizar no significa poder jugar: el juego va por la red privada o la dirección del servidor.

## Columnas

| Columna | Puede estar |
| --- | --- |
| Anfitrión | Disponible · Inaccesible (su Ícaro está cerrado o sin red) |
| Sincronización | Conectando · Conectada · Interrumpida · Reconectando (intento y espera en `mono-sm`) |
| Juego | Servidor alcanzable (dirección y ping) · Sin servidor (el anfitrión no está jugando) · Red privada desconectada |

## Estados del recorrido

| Estado | Anfitrión | Sincronización | Juego |
| --- | --- | --- | --- |
| Conectando | Buscando | Conectando | Sin comprobar |
| Conectado | Disponible | Conectada | Alcanzable |
| Anfitrión inaccesible | Inaccesible | Sin conexión | Sin servidor |
| Interrumpido | Disponible | Interrumpida (se cortó a mitad de descarga; lo descargado se guarda) | Alcanzable |
| Reconectando | Disponible | Reconectando · intento 3 en 12 s | Alcanzable |

Se usa en la tarjeta del servidor compartido en PantallaServidores y arriba de RevisionSincronizacion.

## En iced

Tres `enum` separados en el estado y tres `Subscription`: latido al anfitrión cada 15 s, el canal de sincronización con reconexión exponencial (2, 4, 8… hasta 60 s) y el Server List Ping del juego.
