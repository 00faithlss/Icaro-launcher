# PantallaServidores

Sección Servidores completa: título, accesos para compartir una instancia o aceptar una invitación, la publicación activa si la hay, red privada como estado, lista de servidores guardados con orden manual, y Agregar servidor que abre el PanelLateral de edición.

## Reglas

- Barra de acciones: **Compartir instancia** (abre CompartirInstancia), **Aceptar invitación** (abre EntradaInvitacion) y **Agregar servidor por dirección**, que sigue siendo el principal.
- Si estás compartiendo, una franja arriba resume la publicación (instancia, revisión, sesiones, transferencias) con Ver publicación (PanelPublicacion).
- Las instancias recibidas de otro anfitrión muestran "de Mineral_7" y su ResumenConexion compacto.
- La red privada (ZeroTier) va antes de la lista porque condiciona los servidores de amigos; si no está configurada, ocupa ese lugar el primer uso de RedPrivada.
- Servidores reordenables (ListaReordenable); el orden se refleja en el menú de bandeja.
- Cada servidor vinculado a una instancia muestra con cuál y si sincroniza al iniciar.
- Vacío: EstadoVacio con la lámina de las Alas.

## En iced

El ping de cada servidor (Server List Ping del protocolo de Minecraft) en paralelo con `Task::batch`, refrescado cada 30 s mientras la sección está visible.
