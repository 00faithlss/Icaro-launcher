# CompartirInstancia

Primer paso para compartir una instancia: elegir la instancia anfitriona y revisar qué contenido va a recibir quien acepte la invitación, antes de que se prepare la revisión. Una carreta cargada sale del mercado: lo que se lleva va contado.

## Partes

| Parte | Contenido |
| --- | --- |
| Instancia anfitriona | Selector con icono, nombre, Minecraft, loader y número de mods. Las instancias abiertas en juego aparecen deshabilitadas con "En uso" |
| Resumen | `104 incluidos · 6 excluidos · 2 archivos propios · 1 problema` en `mono-sm` |
| Incluidos | Mods que el invitado descargará de Modrinth o CurseForge. Se muestran 3 y "Ver los 104" |
| Excluidos | Con su motivo: Solo cliente, Desactivado o Lo excluiste tú. Cada fila puede volver a incluirse |
| Archivos propios | `.jar` que no están en ninguna plataforma: se transfieren desde tu equipo y piden ConfirmarJarPropios |
| Carpetas | config, kubejs y resourcepacks se comparten; los mundos y options.txt nunca |
| Problemas | Lo que impide compartir, cada uno con su acción (Excluir, Cerrar Minecraft) |

## Estados

| Estado | Qué se ve | Botón principal |
| --- | --- | --- |
| Analizando | Barra continua "Analizando 64 de 112 archivos"; las listas aún no aparecen | Deshabilitado |
| Contenido bloqueado | Aviso `error` con los problemas arriba de todo | "Resuelve 1 problema", deshabilitado |
| Listo | Resumen y listas | "Revisar archivos propios" (si hay) o "Compartir" |
| Preparando revisión | "Preparando la revisión 7: hashes y archivos propios · 38 %" | Deshabilitado; Cancelar sigue activo |

## Reglas

- Nada se publica hasta terminar la preparación; cancelar en cualquier momento no deja rastro.
- Un archivo de más de 512 MB, un mod sin hash conocido que no se pueda transferir o la instancia abierta en juego son problemas que bloquean.
- Los mundos nunca se comparten por este medio; para eso está ExportarInstancia.

## En iced

El análisis recorre `mods/` con `walkdir`, calcula SHA-1 y SHA-512 en una `Task` y consulta Modrinth (`/v2/version_files`) y CurseForge (`/v1/fingerprints`) en lote para saber qué se puede descargar desde la plataforma y qué es archivo propio.
