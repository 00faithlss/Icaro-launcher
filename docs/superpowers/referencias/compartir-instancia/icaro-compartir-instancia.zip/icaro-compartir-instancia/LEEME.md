# Ícaro · Compartir instancia (versión 29, 7 de noviembre de 2026)

Grupo nuevo "Compartir instancia" con 13 componentes, más PantallaServidores adaptada. Cada carpeta trae README (partes, estados, reglas y traducción a iced) y preview.html funcionando. Los que tienen estados llevan arriba la fila "Estado de ejemplo" para recorrerlos. Agrega `#piedra` al final de la dirección para el tema claro.

Anfitrión: PantallaServidores · CompartirInstancia · ConfirmarJarPropios · PanelPublicacion · InvitacionCompartir · AccesosCompartidos · CierreConTransferencias
Invitado: EntradaInvitacion · IdentidadAnfitrion · SelectorInstanciaDestino · RevisionSincronizacion · ProgresoSincronizacion
Ambos: ResumenConexion · ErroresCompartir
