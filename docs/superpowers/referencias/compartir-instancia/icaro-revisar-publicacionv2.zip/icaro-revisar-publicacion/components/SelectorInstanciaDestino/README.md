# SelectorInstanciaDestino

Aceptar una invitación **siempre crea una instancia nueva**, vinculada al anfitrión. Este paso ya no ofrece instancias existentes: muestra el nombre (editable) y lo que se va a instalar.

## Partes

| Parte | Contenido |
| --- | --- |
| Nombre | Campo con el nombre propuesto, "Amigos (de Mineral_7)". Si ya existe una instancia con ese nombre, se sugiere "Amigos (de Mineral_7) 2" |
| Icono | El de la instancia del anfitrión |
| Qué se instala | Minecraft, loader, mods (de catálogo y archivos propios), carpetas y tamaño de descarga, en filas `dato` |
| Vínculo | "Las próximas sincronizaciones actualizan esta instancia. Siempre verás los cambios antes de aplicarlos." |

## Reglas

- No hay elección de instancia existente: así nunca se pisan mods o configuraciones de otra instancia del invitado.
- El nombre se puede cambiar después sin romper el vínculo.
- Si falta Java para esa versión, la fila Descarga lo suma ("1,3 GB · incluye Java 21").
- Ícaro nunca modifica la instancia vinculada mientras Minecraft la está usando: la sincronización espera a que se cierre.

## En iced

`text_input` para el nombre con validación de duplicados; al confirmar se crea la carpeta de la instancia con un `link.json` que guarda la huella del anfitrión y la última revisión aplicada.
