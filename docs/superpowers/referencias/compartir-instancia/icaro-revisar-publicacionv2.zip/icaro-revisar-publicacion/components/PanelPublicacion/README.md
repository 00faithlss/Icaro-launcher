# PanelPublicacion

La vista del anfitrión mientras comparte: qué instancia, qué revisión está vigente, si está disponible para los invitados, las transferencias en curso, la invitación y los accesos. Vive en Servidores, arriba de la lista, y se abre a pantalla completa desde "Ver publicación".

Instalar, actualizar o quitar contenido en la instancia **no cambia lo que reciben los invitados**: el panel lo detecta y lo deja como "Hay cambios sin publicar" hasta que el anfitrión revisa y publica una revisión en RevisionPublicacion.

## Cabecera

Icono y nombre de la instancia, Minecraft y loader, y la insignia de estado. Debajo, cuatro datos:

| Dato | Ejemplo |
| --- | --- |
| Revisión vigente | `Revisión 7 · 05-11 21:14 · a3f9 c021` |
| Disponibilidad | "Disponible · 2 de 3 en línea", "Pausada: Ícaro en segundo plano", "Detenida" |
| Transferencias | "1 activa · 412 MB por enviar" |
| Tu huella | En `mono` con Copiar, para que el invitado la compare |

## Estados

| Estado | Qué cambia |
| --- | --- |
| Preparando | Primera publicación: barra "Preparando la revisión 7 · 38 %"; la invitación espera |
| Compartiendo | Todo activo; "Contenido privado: 2" con Revisar |
| Cambios sin publicar | Aviso `info` "Hay cambios sin publicar" con el resumen detectado (4 altas · 2 actualizaciones · 2 retiradas · 3 cambios de resourcepacks) y **Revisar cambios**, que abre RevisionPublicacion |
| Preparando revisión 8 | Barra con Cancelar y "Tus amigos siguen recibiendo la revisión 7"; Revisión vigente sigue diciendo 7 |
| Revisión 8 publicada | Aviso `exito` "Publicaste la revisión 8: 1 alta, 1 actualización, 1 retirada. Tus amigos la verán al pulsar Jugar o Sincronizar." Revisión vigente pasa a 8 |
| Detenido | Insignia contorno; invitación y accesos vacíos; botón Volver a compartir |
| Error | Aviso `error` con el motivo y Reintentar; "No se publicó nada. Tus amigos siguen recibiendo la revisión 7." |

## Acciones separadas

Cada acción tiene su lugar y no se mezclan: **Revisar cambios** y Publicar viven en el aviso de cambios; **Generar invitación** en InvitacionCompartir; **Revocar** en cada fila de AccesosCompartidos; **Dejar de compartir** al final de Accesos, con borde propio.

## Reglas

- Nunca se promete que los invitados actualizan solos: revisan y confirman los cambios al pulsar Jugar o Sincronizar.
- Nunca se modifica la instancia de un invitado mientras Minecraft la está usando.

## En iced

Estado `Publicacion { instancia, revision, disponibilidad, transferencias, invitacion, sesiones, pendientes: Resumen }`. Un `notify::Watcher` sobre la carpeta de la instancia recalcula `pendientes` con un retraso de 2 s.
