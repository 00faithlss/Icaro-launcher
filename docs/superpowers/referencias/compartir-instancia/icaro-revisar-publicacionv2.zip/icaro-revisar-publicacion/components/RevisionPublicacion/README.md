# RevisionPublicacion

Donde el anfitrión decide qué cambios de su instancia publica para sus amigos. Funciona como preparar y publicar una versión: elige el contenido, revisa los cambios y publica una revisión. Instalar, actualizar o quitar algo en la instancia **nunca** cambia por sí solo lo que reciben los invitados.

No confundir con RevisionSincronizacion, que es del invitado y revisa lo que se va a aplicar en su equipo.

## Entrada

PanelPublicacion muestra "Hay cambios sin publicar" con **Revisar cambios**, que abre este diálogo.

## Cabecera

Título "Revisar publicación", icono y nombre de la instancia, Minecraft y loader, y `Amigos · Revisión publicada 7 → Nueva revisión 8`. Cerrar con el mismo botón de los demás diálogos.

Aviso `info` debajo: "Los cambios de tu instancia no se comparten hasta que publiques una revisión. El contenido que mantengas privado se queda en tu equipo."

## Resumen

Seis celdas: Altas, Actualizaciones, Retiradas, Resourcepacks, Privado y Problemas. Cada una separa lo **seleccionado para publicar** (número grande) de lo **detectado** ("de 6 detectadas"). Problemas distingue los que bloquean de los que están en contenido privado.

## Grupos

Todas las filas usan `ic-diff` con sus marcas originales: `+` altas, `~` actualizaciones, `−` retiradas, `!` problemas y `=` conservado (privado y packs integrados). Cada fila: nombre, tipo, versión o ruta relativa, tamaño, procedencia (Catálogo: Modrinth o CurseForge, o **Archivo propio**) y la elección.

| Grupo | Elección | Por defecto | Notas |
| --- | --- | --- | --- |
| Contenido nuevo | Compartir · Mantener privado | Sin decidir (queda privado) | "Solo cliente" es información, no prohibición: se puede compartir |
| Actualizaciones | Incluir · Posponer | Incluir | Versión anterior → nueva, o "Contenido modificado". Posponer mantiene la versión publicada; no lo vuelve privado ni lo retira |
| Retiradas | Retirar · Posponer | Retirar | Motivo: "Lo eliminaste de tu instancia" o "Decidiste dejar de compartirlo". Posponer lo mantiene publicado como estaba |
| Resourcepacks | Incluir · Posponer | Incluir | Activación (`+`), desactivación (`−`) y orden de prioridad (`~`). Los packs integrados en un mod se listan como `=` y no se descargan aparte |
| Contenido privado | Incluir | — | Motivo y fecha. La decisión se guarda al momento y se mantiene entre publicaciones |

## Problemas

Arriba de todo, en un aviso `error`, los problemas que bloquean **la selección actual**: archivo inaccesible, mod sin identidad válida, dependencia ausente o preparación fallida. Cada uno con explicación y una acción concreta (Mantener privado, Posponer, Reintentar). Un problema en contenido que no se publica aparece atenuado como "No bloquea: es privado".

## Archivos propios

Si la selección incluye archivos propios nuevos o modificados, el botón principal pasa a "Autorizar 1 archivo propio" y lleva a un paso con el lenguaje de ConfirmarJarPropios (lista con SHA-256 y la casilla de permiso). La autorización vale para ese contenido exacto; los archivos sin cambios ya autorizados no la vuelven a pedir.

## Acciones

- **Cancelar**: cierra sin publicar ni tocar la instancia. Si cambiaste la selección, confirma en el mismo pie: "Tu selección se pierde. Lo que marcaste como privado ya quedó guardado."
- **Publicar revisión 8**: prepara y publica la selección.
- Deshabilitado con su motivo a la izquierda del pie: "Nada que publicar: lo nuevo sigue privado" o "Resuelve 2 problemas para publicar".

## Estados

| Estado | Qué se ve |
| --- | --- |
| Analizando cambios | Barra "Comparando con la revisión 7 · 612 de 1.204 archivos" |
| Sin cambios | "Tu instancia está igual que la revisión 7"; el contenido privado sigue revisable |
| Cambios disponibles | Grupos con sus elecciones por defecto |
| Nuevo mantenido privado | Todo lo nuevo marcado "Privado · guardado" |
| Pospuestas | Filas pospuestas atenuadas con "Se mantiene la 0.14.3 publicada" |
| Autorización pendiente | Botón "Autorizar 1 archivo propio" |
| Bloqueada | Aviso de problemas arriba y botón deshabilitado |
| Preparando revisión | Barra con Cancelar y "Tus amigos siguen recibiendo la revisión 7" |
| Publicada | "Publicaste la revisión 8" con el resumen de lo publicado |
| Error de preparación | Motivo, Reintentar y "No se publicó nada: tus amigos siguen recibiendo la revisión 7" |

Mientras se prepara, la revisión anterior sigue disponible; la nueva aparece para los invitados solo al terminar. Cancelar o fallar nunca deja una revisión a medias. Nunca se promete que los invitados actualizan solos: revisan y confirman al pulsar Jugar o Sincronizar.

## En iced

`struct Borrador { base: Revision, elecciones: HashMap<Ruta, Eleccion> }` con `enum Eleccion { Compartir, Privado, Incluir, Posponer, Retirar }`. Las elecciones Privado se escriben al momento en `privado.json` de la instancia; el resto vive en el borrador. Publicar crea la revisión en una carpeta temporal, calcula hashes y la promueve con un `rename` atómico del manifiesto: hasta ese momento los invitados solo ven la anterior.
