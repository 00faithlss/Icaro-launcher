# InvitacionCompartir

El código que el anfitrión envía para que sus amigos acepten la instancia compartida. Un mismo código sirve para varias personas distintas hasta un límite, y caduca.

## Código

- 12 caracteres en tres grupos de 4 (`7QKM-4XPT-R2C9`), sin letras que se confunden (O/0, I/1/L). Celdas de 36 × 48 con borde de 2 px y `mono` de 24 px.
- Copiar código copia el texto con guiones y cambia a "Copiado" durante 2 s.
- **Generar otro** anula el código anterior en el acto. Los accesos ya aceptados no se tocan.

## Caducidad y cupo

- **Caduca en**: 24 horas (inicial), 2 días o 1 semana, como segmentado.
- **Personas**: límite configurable con − y +, 10 por defecto, de 1 a 50. No puede bajar de las personas que ya aceptaron.
- Cada identidad distinta que acepta gasta un cupo; **reconectarse no gasta otro**.
- Con límite 1 funciona como invitación de un solo uso.
- Progreso del cupo: "3 de 10 personas han aceptado" y una fila de bloques, uno por cupo.
- Al vencer, revocarse o completarse el cupo, el código no admite a nadie más. Quienes ya aceptaron conservan su acceso hasta que se revoque en AccesosCompartidos.

## Estados

| Estado | Insignia | Texto | Acción |
| --- | --- | --- | --- |
| Generando | contorno | Celdas en esqueleto; ajustes editables | — |
| Vigente | exito | "3 de 10 personas han aceptado · caduca en 23 h 41 min" | Copiar, Revocar código, Generar otro |
| Cupo completo | info | "10 de 10 personas han aceptado. El código ya no admite a nadie más." | Generar otra invitación |
| Vencida | alerta | "Venció el 06-11 a las 21:14. Aceptaron 3 de 10 personas." Celdas rayadas | Generar otra invitación |
| Revocada | error | "La revocaste." Celdas rayadas | Generar otra invitación |

## En iced

El código sale de 60 bits aleatorios en Crockford base32. El anfitrión guarda su hash, la caducidad, el límite y la lista de claves públicas que lo aceptaron; una clave que ya está en la lista reconecta sin descontar cupo.
