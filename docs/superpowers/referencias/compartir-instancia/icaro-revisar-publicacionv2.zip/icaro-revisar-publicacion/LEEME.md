# Ícaro · Revisar publicación (versión 31, 7 de noviembre de 2026)

- `components/RevisionPublicacion`: nuevo. El anfitrión elige qué cambios publica en la revisión 8. La preview es interactiva: cambia cada elección y mira cómo se actualizan el resumen, los problemas y el botón; recorre los 10 estados con la fila "Estado de ejemplo".
- `components/PanelPublicacion`: estados Cambios sin publicar, Preparando revisión 8 y Revisión 8 publicada, más el acceso al contenido privado.
- `components/InvitacionCompartir`: caducidad de 24 horas, 2 días o 1 semana; cupo de personas (10 por defecto) con "3 de 10 personas han aceptado"; estado Cupo completo.
- `components/SelectorInstanciaDestino`: aceptar siempre crea una instancia nueva y vinculada.
- `components/EntradaInvitacion`: textos de cupo completo en vez de "una sola persona".
- `components/bundle.css` y `bundle.js`: reemplazan a los anteriores.
- Agrega `#piedra` al final de la dirección para el tema claro.
